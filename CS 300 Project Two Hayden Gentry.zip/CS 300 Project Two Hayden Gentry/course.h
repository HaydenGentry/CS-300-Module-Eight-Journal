#ifndef COURSE_H
#define COURSE_H

#include <string>
#include <vector>

class Course
{
	public:
		// Constructor method 
		Course(const std::string& courseNumber, const std::string& courseTitle,
		const std::string& prerequisites);
		// Accessor methods
		std::string getCourseNumber() const;
		std::string getCourseTitle() const;
		std::string getPrerequisites() const;
		
	private:
		std::string courseNumberPrivate;
		std::string courseTitlePrivate;
		std::vector<std::string> prerequisitesPrivate;
};

#endif
