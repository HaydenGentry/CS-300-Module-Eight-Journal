#include <iostream>
#include <fstream>
#include <algorithm>
#include <vector>
#include <string>
#include "course.h"
#include <sstream>

// Intialize vector and helper variables
std::vector <Course> courses;
std::string filename;
bool loaded = false;

// Display menu method
void displayMenu()
{
	std::cout << "Menu:" << std::endl;
	std::cout << "1. Load Data Structure." << std::endl;
	std::cout << "2. Print Course List." << std::endl;
	std::cout << "3. Print Course." << std::endl;
	std::cout << "9. Exit" << std::endl;
}

// Load data method
void loadData()
{
	// Recieve user input
	std::cout << "Enter the filename: ";
	std::cin >> filename;
	std::ifstream inputFile(filename);
	if (inputFile)
	{
		// Reads data in file and stores data in a vector
		std::string line;
		while (std::getline (inputFile, line))
		{
			std::istringstream iss (line);
			std::string courseNumber, courseTitle, prerequisites;
			std::getline (iss, courseNumber, ',');
			std::getline (iss, courseTitle, ',');
			std::getline (iss, prerequisites, ',');
			courses.push_back(Course(courseNumber, courseTitle, prerequisites));
		}
		// Successfully loads data
		std::cout << "Course data loaded." << std::endl;
		loaded = true;
	}
	// Could not load the data
	else
	{
		std::cout << "Error: Could not open file " << filename << std::endl;
		loaded = false;
	}
}

// Sort data method
void sortData()
{
	// If data has been loaded into the vector
	if (loaded)
	{
		// Intialize new vector to sort the courses
		std::vector <Course> sortedCourses = courses;
		// Sort the courses alphanumerically 
		std::sort (sortedCourses.begin(), sortedCourses.end(), 
		[](const Course & a, const Course & b)
		{
			return a.getCourseNumber() < b.getCourseNumber();
		});
		// Print the sorted courses
		std::cout << "Here is a sample schedule: " << std::endl;
		for (const auto & course:sortedCourses)
		{
			std::cout << course.getCourseNumber() << ": " <<
			course.getCourseTitle() << std::endl;
		}
	}
	// No data has been loaded into the vector
	else
	{
		std::cout << "Error: No course data has been loaded." << std::endl;
	}
}

// Search course method
void searchCourse()
{
	// If data has been loaded into the vector
	if (loaded)
	{
		// Recieve user input
		std::string courseNumber;
		std::cout << "What course do you want to know about? ";
		std::cin >> courseNumber;
		// Search for the course number
		auto it = std::find_if (courses.begin(), courses.end(),
		[courseNumber] (const Course & course)
		{
			return course.getCourseNumber() == courseNumber;
		});
		// If the course number is found
		if (it != courses.end())
		{
			// Print the course number, course title, and its prerequisites
			std::cout << it->getCourseNumber() << ", " <<
			it->getCourseTitle() << std::endl;
			std::cout << "Prerequisites: " << 
			it->getPrerequisites() << std::endl;
		}
		// If the course number is not found
		else
		{
			// Print the course number could not be found
			std::cout << "Error: Course " << courseNumber <<
			 " not found." << std::endl;
		}
	}
	// No data has been loaded into the vector
	else
	{
		std::cout << "Error: No course data has been loaded."
		<< std::endl;
	}
}
// The one and only main function
int main()
{	
	std::cout << "Welcome to the course planner." << std::endl;
	// The main loop
	while(true)
	{
		// Display menu options
		displayMenu();
		// Recieve user input 
		int option;
		std::cout << "What would you like to do? ";
		std::cin >> option;
		
		switch (option)
		{
			// First option
			case 1:
			{
				loadData();
				break;
			}
			// Second option
			case 2:
			{
				sortData();
				break;
			}
			// Third option 
			case 3:
			{
				searchCourse();
				break;
			}
			// Exit option
			case 9:
			{
				std::cout << "Thank you for using the course planner!" << std::endl;
				return 0;
			}
			// Any other options
			default:
				std::cout << option << " is not a valid option." << std::endl;
				break;
				
		}
	}
}
