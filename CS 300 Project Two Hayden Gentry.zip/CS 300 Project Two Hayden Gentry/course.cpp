#include "course.h"
#include <sstream>
// Constructor method 
Course::Course(const std::string& courseNumber, const std::string& courseTitle,
const std::string& prerequisites):
	courseNumberPrivate(courseNumber), courseTitlePrivate(courseTitle)
{
	// Parse line with delimiters to find prerequisites
	std::istringstream iss(prerequisites);
	std::string prerequisite;
	while (std::getline(iss, prerequisite, ','))
	{
		prerequisitesPrivate.push_back(prerequisite);
	}
}
// Accessor methods
std::string Course::getCourseNumber() const
{
	return courseNumberPrivate;
}

std::string Course::getCourseTitle() const
{
	return courseTitlePrivate;
}

std::string Course::getPrerequisites() const
{
	// Put prerequisites into a single string
	std::string prerequisitesString;
	for (const auto& prerequisite : prerequisitesPrivate)
	{
		prerequisitesString += prerequisite + ",";
	}
	if (!prerequisitesString.empty())
	{
		// Remove the comma at the end of the string
		prerequisitesString.pop_back();
	}
	return prerequisitesString;
}
